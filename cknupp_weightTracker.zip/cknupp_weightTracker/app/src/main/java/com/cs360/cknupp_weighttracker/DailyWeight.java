package com.cs360.cknupp_weighttracker;

public class DailyWeight {
    //private variables
    private long mUserID;
    private long mEntryID;
    private String mUsername;
    private String mDate;
    private float mWeight;

    //constructor
    public DailyWeight (long userID, String username, long entryID, String date, float weight){
        mUserID = userID;
        mUsername = username;
        mEntryID = entryID;
        mDate = date;
        mWeight = weight;
    }

    public DailyWeight (DailyWeight dailyWeight) {
        this(dailyWeight.mUserID, dailyWeight.mUsername, dailyWeight.mEntryID, dailyWeight.mDate, dailyWeight.mWeight);
    }

    public String getUsername(){
        return mUsername;
    }


    public long getEntryID () {return mEntryID;}

    public String getDate(){
        return mDate;
    }

    public float getWeight(){
        return mWeight;
    }


    public void setUsername(String username){
        this.mUsername = username;
    }



}

