package com.cs360.cknupp_weighttracker;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.androidplot.xy.XYPlot;
import java.util.List;


public class HomeFragment extends Fragment {

    // widgets
    private TextView mGoalWeightText;

    private XYPlot mLineGraph;
    private RecyclerView mWeightRecycleViewer;

    private AuthenticatedUser mAuthUser;
    private AuthenticatedUserManager mAuthUserManager;
    private DatabaseManager mDBManager;

    private String mUserName;
    private long mUserID;
    private float mGoalWeight;
    private View.OnClickListener onClickListener;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        // Get the username and password from the managers
        mAuthUserManager = AuthenticatedUserManager.getInstance();
        mAuthUser = mAuthUserManager.getUser();
        mDBManager = DatabaseManager.getInstance(this.getContext());
        mUserName = mAuthUserManager.getUser().getUserName();
        mUserID = mDBManager.getUserID(mUserName);

        mGoalWeightText = rootView.findViewById(R.id.goal_weight_banner);
        mLineGraph = rootView.findViewById(R.id.progress_graph);
        //TODO create code to populate graph with entries
        mWeightRecycleViewer = rootView.findViewById(R.id.recyclerView);
        mWeightRecycleViewer.setLayoutManager(new LinearLayoutManager(getActivity()));

        List<DailyWeight> dailyWeights = mDBManager.getDailyWeightList(mUserID, mUserName);
        mWeightRecycleViewer.setAdapter(new DailyWeightAdapter(dailyWeights, onClickListener));


        mGoalWeight = mDBManager.getGoalWeight(mUserName);

        updateGoalBanner(rootView);

        return rootView;
    }


    //gets goal weight for banner, if not set, prompts user to set
    public void updateGoalBanner(View view) {
        if (mGoalWeight != -1) {
            String stringGoalWeight = String.valueOf(mGoalWeight);
            String goalWeightText = getString(R.string.goal_weight_f, stringGoalWeight);
            mGoalWeightText.setText(goalWeightText);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            builder.setTitle("Enter Goal Weight");

            View editView = getLayoutInflater().inflate(R.layout.fragment_goal, null);
            builder.setView(editView);

            EditText enterGoalField = editView.findViewById(R.id.enter_goal_field);

            builder.setPositiveButton("Save", (dialogInterface, i) -> {
                String stringWeight = enterGoalField.getText().toString();
                float enteredGoalWeight = Float.parseFloat(stringWeight.trim());
                boolean isSaved = mDBManager.setGoalWeight(mUserID, mUserName, enteredGoalWeight);
                if (isSaved) {
                    Toast.makeText(view.getContext(), "Goal weight saved.", Toast.LENGTH_SHORT).show();
                    String stringGoalWeight = getString(R.string.goal_weight_f, stringWeight);
                    mGoalWeightText.setText(stringGoalWeight);
                } else {
                    Toast.makeText(view.getContext(), "Error saving goal", Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("Cancel", null);

            builder.create();
            builder.show();
        }

    }

//Recycler for logged weights
    private class DailyWeightAdapter extends RecyclerView.Adapter<DailyWeightHolder> {
        private final List<DailyWeight> mdailyWeightList;

        private final View.OnClickListener mOnClickListener;


        public DailyWeightAdapter(List<DailyWeight> dWeights, View.OnClickListener onClickListener) {
            mdailyWeightList = dWeights;
            mOnClickListener = onClickListener;
        }

        @NonNull
        @Override
        public DailyWeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new DailyWeightHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(DailyWeightHolder holder, int position) {
            DailyWeight dailyWeight = mdailyWeightList.get(position);
            holder.bind(dailyWeight);
            holder.itemView.setTag(dailyWeight.getEntryID());
            holder.itemView.setOnClickListener(mOnClickListener);
            holder.dailyWeight = dailyWeight;
        }

        @Override
        public int getItemCount() {
            return mdailyWeightList.size();
        }
    }

    public class DailyWeightHolder extends RecyclerView.ViewHolder {

        public final TextView mDateTextView;
        public final TextView mWeightTextView;
        public final Button mEditButton;
        public final Button mDeleteButton;
        private DailyWeight dailyWeight;


        public DailyWeightHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_daily_weight, parent, false));
            mDateTextView = itemView.findViewById(R.id.daily_weight_item_date);
            mWeightTextView = itemView.findViewById(R.id.daily_weight_item_weight);
            mEditButton = itemView.findViewById(R.id.edit_weight_button);
            mDeleteButton = itemView.findViewById(R.id.delete_weight_button);

            //on click listeners with alerts dialogue if clicked
            mEditButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Edit Weight");

                    View editView = getLayoutInflater().inflate(R.layout.fragment_edit_weight, null);
                    builder.setView(editView);

                    TextView originalDate = editView.findViewById(R.id.edit_date_label);
                    String stringDate = dailyWeight.getDate();
                    String dateText = getString(R.string.original_date, stringDate);
                    originalDate.setText(dateText);


                    EditText enterWeightField = editView.findViewById(R.id.enter_weight_field2);
                    enterWeightField.setText(String.valueOf(dailyWeight.getWeight()));


                    builder.setPositiveButton("Save", (dialogInterface, i) -> {
                        String stringWeight = enterWeightField.getText().toString();
                        float enteredWeight = Float.parseFloat(stringWeight.trim());
                        boolean isSaved = mDBManager.updateDailyWeight(dailyWeight.getEntryID(), dailyWeight.getDate(),enteredWeight);
                        if (isSaved) {
                            Toast.makeText(view.getContext(), "Weight edited.", Toast.LENGTH_SHORT).show();
                            mWeightTextView.setText(stringWeight);
                        } else {
                            Toast.makeText(view.getContext(), "Error editing", Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.setNegativeButton("Cancel", null);

                    builder.create();
                    builder.show();

                }
            });
            mDeleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Delete Entry");

                    View editView = getLayoutInflater().inflate(R.layout.fragment_delete_weight, null);
                    builder.setView(editView);

                    TextView askToConfirm = editView.findViewById(R.id.confirm_delete_textview);


                    builder.setPositiveButton("Delete", (dialogInterface, i) -> {
                        boolean isDeleted = mDBManager.deleteDailyWeight(dailyWeight.getEntryID());
                        if (isDeleted) {
                            Toast.makeText(view.getContext(), "Entry deleted.", Toast.LENGTH_SHORT).show();
                            List<DailyWeight> dailyWeights = mDBManager.getDailyWeightList(mUserID, mUserName);
                            mWeightRecycleViewer.setAdapter(new DailyWeightAdapter(dailyWeights, onClickListener));
                        } else {
                            Toast.makeText(view.getContext(), "Error deleting", Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.setNegativeButton("Cancel", null);

                    builder.create();
                    builder.show();

                }
            });
        }

        public void bind(DailyWeight dailyWeight) {
            String date = dailyWeight.getDate();
            float weight = dailyWeight.getWeight();

            String dailyWeightInfo = Float.toString(weight);
            mDateTextView.setText(date);
            mWeightTextView.setText(dailyWeightInfo);


        }

    }
}



