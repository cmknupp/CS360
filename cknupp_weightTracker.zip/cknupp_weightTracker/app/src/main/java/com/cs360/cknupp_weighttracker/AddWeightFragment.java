package com.cs360.cknupp_weighttracker;

import android.app.DatePickerDialog;
import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;


public class AddWeightFragment extends Fragment {

    private TextView mFormatInfoText;
    private Button mSelectDateButton;
    private EditText mEnterWeightInput;
    private Button mSaveButton;

    private AuthenticatedUser mAuthUser;
    private DatabaseManager mDBManager;

    private int todayYear;
    private int todayMonth;
    private int todayDay;

    private String dateEntered;
    private float weightEntered;
    private boolean isDateSelected = false;

    public AddWeightFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the username and password from the authenticated user manager
        AuthenticatedUserManager mAuthenticatedUserManager = AuthenticatedUserManager.getInstance();
        mAuthUser = mAuthenticatedUserManager.getUser();
        mDBManager = DatabaseManager.getInstance(this.getContext());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_add_weight, container, false);

        mSelectDateButton = rootView.findViewById(R.id.select_date_button);
        mSelectDateButton.setText(getTodayDate());
        mEnterWeightInput = rootView.findViewById(R.id.enter_weight_field);
        mSaveButton = rootView.findViewById(R.id.save_button);
        mFormatInfoText=rootView.findViewById(R.id.date_format_text);
        Button mCancelButton = rootView.findViewById(R.id.cancel_button);

        //todays date to populate calendar
        Calendar cal = Calendar.getInstance();
        todayYear = cal.get(Calendar.YEAR);
        todayMonth = cal.get(Calendar.MONTH);
        todayDay = cal.get(Calendar.DAY_OF_MONTH);

        //listeners
        mSaveButton.setOnClickListener(this::saveWeighIn);
        mCancelButton.setOnClickListener(this::cancelButtonPushed);
        mSelectDateButton.setOnClickListener(this::openDateDialog);
        mEnterWeightInput.addTextChangedListener(inputTextWatcher);


        return rootView;
    }

    //gets text input
    TextWatcher inputTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            Editable editableWeight = mEnterWeightInput.getText();
            String stringWeight = editableWeight.toString();
            weightEntered = Float.parseFloat(stringWeight.trim());

            //enable button with input
            mSaveButton.setEnabled(!stringWeight.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    //for date button
    private void openDateDialog (View view) {
        if (this.getContext() != null) {
            DatePickerDialog dateDialog = new DatePickerDialog(this.getContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    dateEntered = makeDateString(year, month, dayOfMonth);
                    mFormatInfoText.setVisibility(View.VISIBLE);
                    mSelectDateButton.setText(makeDateString(year, month, dayOfMonth));
                    isDateSelected = true;
                }
            }, todayYear, todayMonth, todayDay);
            dateDialog.show();
        }
    }

    //saves weigh in to database
    private void saveWeighIn (View view) {
        String userName = mAuthUser.getUserName();
        long userID = mDBManager.getUserID(userName);
        //if not selected default to todays date
        if (!isDateSelected) {
            dateEntered = getTodayDate();
        }
        boolean addWeightSuccess = mDBManager.addDailyWeight(userID, userName, dateEntered, weightEntered);
        if (addWeightSuccess) {
            Toast.makeText(view.getContext(), "Successfully added.", Toast.LENGTH_SHORT).show();
            checkIfMadeGoal(mAuthUser.getUserID(), weightEntered);
            Navigation.findNavController(view).navigate(R.id.home_menu);
        } else {
            Toast.makeText(view.getContext(), "Error occurred.", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelButtonPushed (View view){
        Toast.makeText(view.getContext(), "Cancelled add.", Toast.LENGTH_SHORT).show();
        Navigation.findNavController(view).navigate(R.id.home_menu);
    }

    private String makeDateString(int year, int month, int day) {
        return year + "/" + month + "/" + day;
    }



    private String getTodayDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month +1;
        int day = cal.get(Calendar.DAY_OF_MONTH);

        return makeDateString(year, month, day);
    }

    //sends SMS is goal is reached, phone number is saved and permissions are granted
    private void checkIfMadeGoal (long userID, float savedWeight) {
        if (savedWeight <= mDBManager.getGoalWeight(userID)) {
            NotificationsManager.initialize(getContext(), mAuthUser.getUserName());
            if (mDBManager.checkPhoneExists(userID) && NotificationsManager.getInstance().getNotificationsPrefs()) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(mDBManager.getPhoneNumber(userID), null, "CONGRATULATIONS on reaching your goal!", null, null);
                    Toast.makeText(getContext(), "CONGRATULATIONS SMS sent!.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Error sending SMS.", Toast.LENGTH_SHORT).show();
                }

            }
        }
    }
}