package com.cs360.cknupp_weighttracker;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.navigation.Navigation;
import android.widget.Toast;

public class LoginFragment extends Fragment {

    public static NewUser ARG_USER= null;

    private NewUser newUser;
    private long mUserID;
    private EditText mUserName_input;
    private EditText mPassword_input;

    private Button mLoginButton;
    private Button mNewUserButton;


    private DatabaseManager mDBManager;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the username and password from the fragment arguments
        Bundle args = getArguments();
        if (args != null) {
            newUser = args.getParcelable("ARG_USER");

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);


        mPassword_input = rootView.findViewById(R.id.password_input);
        mUserName_input = rootView.findViewById(R.id.username_input);
        mLoginButton = rootView.findViewById(R.id.login_Button);
        mNewUserButton = rootView.findViewById(R.id.new_user_button);
        mDBManager = DatabaseManager.getInstance(getContext());

        mLoginButton.setOnClickListener(this::onLoginClick);
        mNewUserButton.setOnClickListener(this::onNewUserClick);
        mPassword_input.addTextChangedListener(inputTextWatcher);
        mUserName_input.addTextChangedListener(inputTextWatcher);

        if (newUser != null) {
            mUserName_input.setText(newUser.getUsername());
            mPassword_input.setText(newUser.getPassword());
        }
        return rootView;
    }
    TextWatcher inputTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String userName = mUserName_input.getText().toString().trim().toLowerCase();
            String password = mPassword_input.getText().toString();

            //enable button with input in both fields
            mLoginButton.setEnabled(!userName.isEmpty() && !password.isEmpty());
            mNewUserButton.setEnabled(!userName.isEmpty() && !password.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void onLoginClick(View view) {
        String username = mUserName_input.getText().toString().trim();
        String password = mPassword_input.getText().toString();

        //check against database
        boolean validCredentials = mDBManager.checkUsernamePassword(username, password);

        if (validCredentials) {
            //launch main activity
            Toast.makeText(view.getContext(), "Logging in.", Toast.LENGTH_SHORT).show();
            mUserID = mDBManager.getUserID(username);
            launchActivityMain(view);
        }
        else {
            Toast.makeText(view.getContext(), "Invalid Credentials.", Toast.LENGTH_SHORT).show();
        }

    }

    public void onNewUserClick(View view) {
        String username = mUserName_input.getText().toString().trim();
        String password = mPassword_input.getText().toString();


        boolean checkUserExists = mDBManager.userNameExists(username);
        if (!checkUserExists) {

            // create newUser
            NewUser newUser = new NewUser(username, password);

            //create argument Bundle
            Bundle args = new Bundle();
            args.putParcelable("ARG_USER", newUser);

            //Send arguments to ConfirmFragment
            Navigation.findNavController(view).navigate(R.id.confirm_screen, args);
        }
        else {
            Toast.makeText(view.getContext(), "Username already exists, please login.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * launches main activity after successful login
     *
     * @param - view
     */
    public void launchActivityMain(View view) {
        AuthenticatedUser authUser = new AuthenticatedUser(mUserID, mUserName_input.getText().toString());
        AuthenticatedUserManager.getInstance().setUser(authUser);
        Intent i = new Intent(view.getContext(), MainActivity.class);
        startActivity(i);
    }

}