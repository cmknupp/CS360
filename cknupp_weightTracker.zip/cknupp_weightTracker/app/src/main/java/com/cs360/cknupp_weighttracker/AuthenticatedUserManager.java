package com.cs360.cknupp_weighttracker;

//to hold/track authenticated user after sign=in
public class AuthenticatedUserManager {
    private AuthenticatedUser user;
    private static AuthenticatedUserManager instance;

    private static final String INFO = "user_database";
    private AuthenticatedUserManager() {
        //no implementation
    }

    /**
     * Get a singleton instance of manager
     * @return - singleton instance of manager
     */
    public static AuthenticatedUserManager getInstance() {
        if (instance == null) {
            instance = new AuthenticatedUserManager();
        }
        return instance;
    }

    /**
     * Get the authenticated user
     * @return the authenticated user
     */
    public AuthenticatedUser getUser() {
        return user;
    }

    public void setUser(AuthenticatedUser user) {
        this.user = user;
    }
}
