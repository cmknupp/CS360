package com.cs360.cknupp_weighttracker;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import androidx.navigation.Navigation;


public class ConfirmFragment extends Fragment {

    public static NewUser ARG_USER= null;

    private NewUser newUser;

    private EditText mUserName_input;
    private EditText mPassword_input;

    private EditText mConfirmPassword_input;
    private Button mConfirmButton;
    private DatabaseManager mDBManager;

    public ConfirmFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the username and password from the fragment arguments
        Bundle args = getArguments();
        if (args != null) {
            newUser = args.getParcelable("ARG_USER");

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_confirm, container, false);

        mUserName_input = rootView.findViewById(R.id.username_input1);
        mPassword_input = rootView.findViewById(R.id.password_input1);

        //entered passed in arguments
        if (newUser != null) {
            mUserName_input.setText(newUser.getUsername());
            mPassword_input.setText(newUser.getPassword());
        }

        mDBManager = DatabaseManager.getInstance(rootView.getContext());
        mConfirmButton = rootView.findViewById(R.id.confirm_Button1);
        mConfirmPassword_input = rootView.findViewById(R.id.confirm_password_input1);

        mConfirmButton.setOnClickListener(this::onConfirmClick);
        mPassword_input.addTextChangedListener(inputTextWatcher);
        mUserName_input.addTextChangedListener(inputTextWatcher);
        mConfirmPassword_input.addTextChangedListener(inputTextWatcher);

        return rootView;
    }

    TextWatcher inputTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String userName = mUserName_input.getText().toString().trim().toLowerCase();
            String password = mPassword_input.getText().toString();
            String confirmedPassword = mConfirmPassword_input.getText().toString();

            //enable button with input in both fields
            mConfirmButton.setEnabled(!userName.isEmpty() && !password.isEmpty() && !confirmedPassword.isEmpty());

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };


    //ensures passwords match and user is unique
    public void onConfirmClick(View view) {
        String username = mUserName_input.getText().toString().trim();
        String password = mPassword_input.getText().toString();
        String confirmPass = mConfirmPassword_input.getText().toString();

        boolean checkUserExists = mDBManager.userNameExists(username);
        if (!checkUserExists) {
            if (password.equals(confirmPass)) {
                long insertedID = mDBManager.addUser(username, password);
                if (insertedID > -1) {
                    Toast.makeText(view.getContext(), "Account created.", Toast.LENGTH_LONG).show();

                    //create argument Bundle
                    Bundle args = new Bundle();
                    args.putParcelable("ARG_USER", newUser);

                    //Send arguments to LoginFragment
                    Navigation.findNavController(view).navigate(R.id.login_screen, args);
                } else {
                    Toast.makeText(view.getContext(), "Passwords do not match.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(view.getContext(), "Username already exists, please login.", Toast.LENGTH_SHORT).show();
                Navigation.findNavController(view).navigate(R.id.login_screen);
            }
        }
    }

}