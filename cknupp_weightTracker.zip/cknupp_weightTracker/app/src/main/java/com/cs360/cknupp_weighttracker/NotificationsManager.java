package com.cs360.cknupp_weighttracker;

import android.content.Context;
import android.content.SharedPreferences;

public class NotificationsManager {
    private static SharedPreferences sharedPrefs;
    private static SharedPreferences.Editor editor;

    private static final String INFO = "notifications_prefs";

    private static NotificationsManager instance;

    private String username;

    /**
     * Constructor
     * @param context - the context
     * @param username - the current username
     */
    private NotificationsManager (Context context, String username) {
        this.username = username;
        sharedPrefs = context.getSharedPreferences(INFO, Context.MODE_PRIVATE);
        editor = sharedPrefs.edit();
        editor.apply();
    }

    /**
     * Initializes the notifications manager
     * @param context - the context
     * @param username - the current username
     */
    public static void initialize (Context context, String username) {
        if (instance == null) {
            instance = new NotificationsManager(context, username);
        }
    }

    /**
     * Get the singleton instance
     * Throws IllegalStateException if instance has not been initialized;
     * @return - the NotificationsManager Instance
     */
    public static NotificationsManager getInstance() {
        if (instance == null){
            throw new IllegalStateException("Notifications manager has not been initialized");
        }
        return instance;
    }

    //set username
    public void setUsername (String username) {
        this.username = username;
    }

    //save preferences
    public void saveNotificationsPrefs(boolean isEnabled) {
        editor.putBoolean(username, isEnabled);
        editor.apply();
    }

    // returns false if not set
    public boolean getNotificationsPrefs() {
        return sharedPrefs.getBoolean(username, false);
    }

    //remove preferences
    public void removeNotificationsPrefs() {
        if (sharedPrefs.contains(username)){
            editor.remove(username);
            editor.apply();
        }
    }
}
