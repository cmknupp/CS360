package com.cs360.cknupp_weighttracker;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** @noinspection Annotator, Annotator */
public class DatabaseManager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int VERSION = 1;

    private static DatabaseManager instance;

    private DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        Resources res = context.getResources();

    }

    public static DatabaseManager getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseManager(context);
        }
        return instance;
    }

    private final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "Username";
        private static final String COL_PASSWORD = "Password";
    }

    private static final String createUserString = String.format("create table %s (%s INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "%s text, %s text)", UserTable.TABLE, UserTable.COL_ID, UserTable.COL_USER, UserTable.COL_PASSWORD);


    private static final class DailyWeights {
        private static final String TABLE = "Daily_Weights";
        private static final String COL_USER_ID = "User_ID";
        private static final String COL_USER = "Username";
        private static final String COL_ENTRY_ID = "Entry_ID";
        private static final String COL_DATE = "Date";
        private static final String COLUMN_WEIGHT = "Weight";
    }

    private static final String createDailyWeightsString = String.format("create table %s (%s integer,  %s text, %s integer primary " +
                    "key autoincrement, %s text, %s text)", DailyWeights.TABLE, DailyWeights.COL_USER_ID, DailyWeights.COL_USER, DailyWeights.COL_ENTRY_ID,
            DailyWeights.COL_DATE, DailyWeights.COLUMN_WEIGHT);

    private static final class GoalWeight {
        private static final String TABLE = "Goal_Weight";
        private static final String COL_USER_ID = "User_ID";
        private static final String COL_USER = "Username";
        private static final String COL_WEIGHT = "Weight";
    }


    private static final String createGoalWeightString = String.format("create table %s (%s integer primary key, %s text, %s float)", GoalWeight.TABLE, GoalWeight.COL_USER_ID,
            GoalWeight.COL_USER, GoalWeight.COL_WEIGHT);

    private static final class PhoneNumber {
        private static final String TABLE = "Phone_Number";
        private static final String COL_USER_ID = "User_ID";
        private static final String COL_PHONE = "Phone_num";
    }

    private static final String createPhoneNumberString = String.format("create table %s (%s integer primary key, %s text)"
            , PhoneNumber.TABLE, PhoneNumber.COL_USER_ID, PhoneNumber.COL_PHONE);

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create tables
        db.execSQL(createUserString);
        db.execSQL(createDailyWeightsString);
        db.execSQL(createGoalWeightString);
        db.execSQL(createPhoneNumberString);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + DailyWeights.TABLE);
        db.execSQL("drop table if exists " + GoalWeight.TABLE);
        db.execSQL("drop table if exists " + PhoneNumber.TABLE);
        onCreate(db);
    }

    public long addUser(String user, String password) {
        long result = -1;
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UserTable.COL_USER, user);
        contentValues.put(UserTable.COL_PASSWORD, password);

        result = myDB.insert(UserTable.TABLE, null, contentValues);
        myDB.close();
        return result;
    }


    public boolean userNameExists(String user) {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where Username = ?", new String[]{user});
        if (cursor.getCount() > 0) {
            cursor.close();
            myDB.close();
            return true;
        } else {
            cursor.close();
            myDB.close();
            return false;
        }
    }

    public long getUserID(String userName) {
        long userID = -1;
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where Username = ?", new String[]{userName});
        if (cursor.moveToFirst()) {
            {
                userID = cursor.getLong(0);
            }
        }
        cursor.close();
        myDB.close();
        return userID;
    }

    public boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where Username = ? and Password = ?", new String[]{username, password});
        if (cursor.getCount() > 0) {
            cursor.close();
            myDB.close();
            return true;
        } else {
            cursor.close();
            myDB.close();
            return false;
        }
    }

    public List<DailyWeight> getDailyWeightList(long userID, String username) {
        List<DailyWeight> dailyWeights = new ArrayList<>();

        SQLiteDatabase myDB = getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Daily_Weights where  User_ID = ? AND Username = ?", new String[]{Long.toString(userID), username});

        if (cursor.moveToFirst()) {
            do {
                long userId = cursor.getLong(0);
                String userName = cursor.getString(1);
                long entryId = cursor.getLong(2);
                String date = cursor.getString(3);
                float weight = cursor.getFloat(4);

                DailyWeight dailyWeight = new DailyWeight(userId, userName, entryId, date, weight);
                dailyWeights.add(dailyWeight);
            } while (cursor.moveToNext());
        }
        return dailyWeights;
    }

    public boolean addDailyWeight(long userID, String user, String date, float weight) {
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DailyWeights.COL_USER_ID, userID);
        contentValues.put(DailyWeights.COL_USER, user);
        contentValues.put(DailyWeights.COL_DATE, date);
        contentValues.put(DailyWeights.COLUMN_WEIGHT, weight);

        long result = myDB.insert(DailyWeights.TABLE, null, contentValues);
        myDB.close();
        return result != -1;
    }


    public boolean updateDailyWeight(long entryID, String date, float weight) {
        SQLiteDatabase myDB = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DailyWeights.COLUMN_WEIGHT, weight);
        values.put(DailyWeights.COL_DATE, date);

        int rowsUpdated = myDB.update(DailyWeights.TABLE, values, "Entry_ID = ?", new String[]{Long.toString(entryID)});
        myDB.close();
        return rowsUpdated > 0;
    }


    public boolean deleteDailyWeight(long entry_ID) {
        SQLiteDatabase myDB = getWritableDatabase();
        String selection = "Entry_ID = ?";
        String[] selectionArgs = {Long.toString(entry_ID)};
        int rowsDeleted = myDB.delete(DailyWeights.TABLE, selection, selectionArgs);
        myDB.close();
        return rowsDeleted > 0;
    }

    public float getGoalWeight(String username) {
        float weight = -1;
        SQLiteDatabase myDB = getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Goal_Weight where Username = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            {
                weight = cursor.getFloat(2);
            }
        }
        cursor.close();
        myDB.close();
        return weight;
    }

    public float getGoalWeight(long userID) {
        float weight = -1;
        SQLiteDatabase myDB = getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Goal_Weight where User_ID = ?", new String[]{Long.toString(userID)});
        if (cursor.moveToFirst()) {
            {
                weight = cursor.getFloat(2);
            }
        }
        cursor.close();
        myDB.close();
        return weight;
    }


    public boolean setGoalWeight(long userID, String userName, float weight) {
        long result;
        boolean alreadyExists = checkGoalExists(userName);
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        if (!alreadyExists) {
            contentValues.put(GoalWeight.COL_USER_ID, userID);
            contentValues.put(GoalWeight.COL_USER, userName);
            contentValues.put(GoalWeight.COL_WEIGHT, weight);
            result = myDB.insert(GoalWeight.TABLE, null, contentValues);
        } else {
            contentValues.put(GoalWeight.COL_WEIGHT, weight);
            result = myDB.update(GoalWeight.TABLE, contentValues, "Username = ?", new String[]{userName});
        }
        myDB.close();
        return (result > 0);
    }


    public boolean checkGoalExists(String username) {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Goal_Weight where Username = ?", new String[]{username});
        if (cursor.getCount() > 0) {
            cursor.close();
            myDB.close();
            return true;
        } else {
            cursor.close();
            myDB.close();
            return false;
        }
    }

    public boolean checkGoalExists(long userID) {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Goal_Weight where User_ID = ?", new String[]{Long.toString(userID)});
        if (cursor.getCount() > 0) {
            cursor.close();
            myDB.close();
            return true;
        } else {
            cursor.close();
            myDB.close();
            return false;
        }
    }

    public boolean checkPhoneExists(long userID) {
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Phone_Number where User_ID = ?", new String[]{Long.toString(userID)});
        if (cursor.getCount() > 0) {
            cursor.close();
            myDB.close();
            return true;
        } else {
            cursor.close();
            myDB.close();
            return false;
        }
    }

    public String getPhoneNumber (long userID){
        String phone_num = "";
        SQLiteDatabase myDB = getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from Phone_Number where User_ID = ?", new String[]{Long.toString(userID)});
        if (cursor.moveToFirst()) {
            {
                phone_num = cursor.getString(1);
            }
        }
        cursor.close();
        myDB.close();
        return phone_num;
    }

    public boolean setPhoneNumber(long userID, String phoneNum) {
        long result;
        boolean phoneExistForUser = checkPhoneExists(userID);
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        if (!phoneExistForUser) {
            contentValues.put(PhoneNumber.COL_USER_ID, userID);
            contentValues.put(PhoneNumber.COL_PHONE, phoneNum);
            result = myDB.insert(PhoneNumber.TABLE, null, contentValues);
        } else {
            contentValues.put(PhoneNumber.COL_PHONE, phoneNum);
            result = myDB.update(PhoneNumber.TABLE, contentValues, "User_ID = ?", new String[]{Float.toString(userID)});
        }
        myDB.close();
        return (result > 0);
    }
}
