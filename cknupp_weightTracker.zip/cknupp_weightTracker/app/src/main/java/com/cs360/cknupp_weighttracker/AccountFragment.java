package com.cs360.cknupp_weighttracker;

import static androidx.appcompat.content.res.AppCompatResources.getDrawable;
import static androidx.core.content.ContextCompat.checkSelfPermission;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.materialswitch.MaterialSwitch;

public class AccountFragment extends Fragment {
    private AuthenticatedUser mAuthUser;
    private DatabaseManager mDBManager;
    private TextView mUserNameTextDisplay;
    private TextView mGoalWeightTextDisplay;
    private Button mEditGoalButton;

    private TextView mPhoneNumberDisplay;
    private Button mEditPhoneButton;
    private MaterialSwitch mNotificationsSwitch;
    private NotificationsManager mNotificationManager;

    private float mGoalWeight;

    private String mPhoneNumber = null;

    public AccountFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the username and password from the authenticated user manager
        AuthenticatedUserManager mAuthenticatedUserManager = AuthenticatedUserManager.getInstance();
        mAuthUser = mAuthenticatedUserManager.getUser();
        mDBManager = DatabaseManager.getInstance(this.getContext());
        mGoalWeight = mDBManager.getGoalWeight(mAuthUser.getUserID());
        if (mDBManager.checkPhoneExists(mAuthUser.getUserID())){
            mPhoneNumber = mDBManager.getPhoneNumber(mAuthUser.getUserID());
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView =  inflater.inflate(R.layout.fragment_account, container, false);

        //assign display items
        mUserNameTextDisplay = rootView.findViewById(R.id.username_label);
        mGoalWeightTextDisplay = rootView.findViewById(R.id.goal_weight_display);
        mEditGoalButton = rootView.findViewById(R.id.edit_goal_button);
        mNotificationsSwitch = rootView.findViewById(R.id.notification_switch);
        mPhoneNumberDisplay = rootView.findViewById(R.id.phone_num_display);
        mEditPhoneButton = rootView.findViewById(R.id.edit_phone_button);

        //onclick listeners
        mEditGoalButton.setOnClickListener(this::onEditGoalSelect);
        mEditPhoneButton.setOnClickListener(this::onPhoneClicked);
        mNotificationsSwitch.setOnClickListener(this::onSwitchClick);

        //initialize notification manager
        NotificationsManager.initialize(getContext(), mAuthUser.getUserName());
        mNotificationManager = NotificationsManager.getInstance();

        //set notifications switch to saved state
        mNotificationsSwitch.setChecked(NotificationsManager.getInstance().getNotificationsPrefs());

        updateDisplayText(rootView);

        return rootView;
    }

    //adds user information
    public void updateDisplayText(View view) {
        mUserNameTextDisplay.setText(getString(R.string.username_username, mAuthUser.getUserName()));
        if (mGoalWeight != -1) {
            String stringGoalWeight = String.valueOf(mGoalWeight);
            String goalWeightText = getString(R.string.goal_weight_f, stringGoalWeight);
            mGoalWeightTextDisplay.setText(goalWeightText);
        } else {  //gets goal weight if empty
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            builder.setTitle("Enter Goal Weight");

            View editView = getLayoutInflater().inflate(R.layout.fragment_goal, null);
            builder.setView(editView);

            EditText enterGoalField = editView.findViewById(R.id.enter_goal_field);

            builder.setPositiveButton("Save", (dialogInterface, i) -> {
                String stringWeight = enterGoalField.getText().toString();
                float enteredGoalWeight = Float.parseFloat(stringWeight.trim());
                boolean isSaved = mDBManager.setGoalWeight(mAuthUser.getUserID(), mAuthUser.getUserName(), enteredGoalWeight);
                if (isSaved) {
                    Toast.makeText(view.getContext(), "Goal weight saved.", Toast.LENGTH_SHORT).show();
                    String stringGoalWeight = getString(R.string.goal_weight_f, stringWeight);
                    mGoalWeightTextDisplay.setText(stringGoalWeight);
                } else {
                    Toast.makeText(view.getContext(), "Error saving goal", Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("Cancel", null);

            builder.create();
            builder.show();
        }
        if (mPhoneNumber != null && !mPhoneNumber.isEmpty()) {
            String phoneNumUpdateText = getString(R.string.phone_number_s, mPhoneNumber);
            mPhoneNumberDisplay.setText(phoneNumUpdateText);
        } else {  //gets phone number if empty
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            builder.setTitle("Enter Phone Number");

            View editView = getLayoutInflater().inflate(R.layout.fragment_phone, null);
            builder.setView(editView);

            EditText enterPhoneField = editView.findViewById(R.id.enter_phone_field);

            builder.setPositiveButton("Save", (dialogInterface, i) -> {
                String stringPhone = enterPhoneField.getText().toString();
                if (stringPhone.length() < 10) {
                    Toast.makeText(view.getContext(), "Invalid phone number", Toast.LENGTH_SHORT).show();
                }else {
                    boolean isSaved = mDBManager.setPhoneNumber(mAuthUser.getUserID(), stringPhone);
                    if (isSaved) {
                        Toast.makeText(view.getContext(), "Phone number saved.", Toast.LENGTH_SHORT).show();
                        String stringPhoneText = getString(R.string.phone_number_s, stringPhone);
                        mPhoneNumber = stringPhoneText;
                        mPhoneNumberDisplay.setText(stringPhoneText);
                    } else {
                        Toast.makeText(view.getContext(), "Error saving goal", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            builder.setNegativeButton("Cancel", null);

            builder.create();
            builder.show();
        }
    }

    //edits goal weight
    private void onEditGoalSelect (View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setTitle("Enter Goal Weight");

        View editView = getLayoutInflater().inflate(R.layout.fragment_goal, null);
        builder.setView(editView);

        EditText enterGoalField = editView.findViewById(R.id.enter_goal_field);

        builder.setPositiveButton("Save", (dialogInterface, i) -> {
            String stringWeight = enterGoalField.getText().toString();
            float enteredGoalWeight = Float.parseFloat(stringWeight.trim());
            boolean isSaved = mDBManager.setGoalWeight(mAuthUser.getUserID(), mAuthUser.getUserName(), enteredGoalWeight);
            if (isSaved) {
                Toast.makeText(view.getContext(), "Goal weight saved.", Toast.LENGTH_SHORT).show();
                String stringGoalWeight = getString(R.string.goal_weight_f, stringWeight);
                mGoalWeightTextDisplay.setText(stringGoalWeight);
            } else {
                Toast.makeText(view.getContext(), "Error saving goal", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", null);

        builder.create();
        builder.show();
    }

    //edits goal weight
    private void onPhoneClicked (View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
        builder.setTitle("Enter Phone Number");

        View editView = getLayoutInflater().inflate(R.layout.fragment_phone, null);
        builder.setView(editView);

        EditText enterPhoneField = editView.findViewById(R.id.enter_phone_field);

        builder.setPositiveButton("Save", (dialogInterface, i) -> {
            String stringPhone = enterPhoneField.getText().toString();
            if (stringPhone.length() < 10) {
                Toast.makeText(view.getContext(), "Invalid phone number", Toast.LENGTH_SHORT).show();
            }else {
                boolean isSaved = mDBManager.setPhoneNumber(mAuthUser.getUserID(), stringPhone);
                if (isSaved) {
                    Toast.makeText(view.getContext(), "Phone number saved.", Toast.LENGTH_SHORT).show();
                    String stringPhoneText = getString(R.string.phone_number_s, stringPhone);
                    mPhoneNumber = stringPhoneText;
                    mPhoneNumberDisplay.setText(stringPhoneText);
                } else {
                    Toast.makeText(view.getContext(), "Error saving phone number", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);

        builder.create();
        builder.show();
    }


    //notifications switch
    private void onSwitchClick(View view) {
        mPhoneNumber = mDBManager.getPhoneNumber(mAuthUser.getUserID());
        mNotificationsSwitch.setThumbDrawable(getDrawable(getContext(), R.drawable.ic_notifications));
        //if phone number is saved
        if (mPhoneNumber != null && !mPhoneNumber.isEmpty()) {
            //if SMS enabled is switched on
            if (mNotificationsSwitch.isChecked()) {
                //if no permissions
                if (!mNotificationManager.getNotificationsPrefs()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Enable notifications");

                    View editView = getLayoutInflater().inflate(R.layout.fragment_notification, null);
                    builder.setView(editView);


                    builder.setPositiveButton("Enable", (dialogInterface, i) -> {
                        mNotificationManager.saveNotificationsPrefs(true);
                        Toast.makeText(view.getContext(), "Notifications enabled", Toast.LENGTH_SHORT).show();
                    });
                    builder.setNegativeButton("Cancel", (dialogInterface, j) -> {
                        mNotificationManager.saveNotificationsPrefs(false);
                        Toast.makeText(view.getContext(), "Notifications disabled", Toast.LENGTH_SHORT).show();
                        mNotificationsSwitch.setChecked(false);
                        mNotificationsSwitch.setThumbDrawable(getDrawable(getContext(), R.drawable.ic_cancel));
                    });

                    builder.create();
                    builder.show();
                }
                // if phone is saved and has permissions
                else {
                    mNotificationsSwitch.setChecked(mNotificationManager.getNotificationsPrefs());
                }
            }
            //if switched off
            else {
                mNotificationManager.saveNotificationsPrefs(false);
                mNotificationsSwitch.setChecked(false);
                mNotificationsSwitch.setThumbDrawable(getDrawable(getContext(), R.drawable.ic_cancel));
            }
        }else {// no phone number is saved
            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
            builder.setTitle("Enable notifications");

            View editView = getLayoutInflater().inflate(R.layout.fragment_notification, null);
            builder.setView(editView);

            EditText enterPhoneField = editView.findViewById(R.id.enter_phone_field);
            enterPhoneField.setVisibility(View.VISIBLE);

            builder.setPositiveButton("Enable", (dialogInterface, i) -> {
                String phoneNumText = enterPhoneField.getText().toString();
                if (phoneNumText.length() < 10) {
                    Toast.makeText(view.getContext(), "Invalid phone number", Toast.LENGTH_SHORT).show();
                }else {
                    boolean phoneSaved = mDBManager.setPhoneNumber(mAuthUser.getUserID(), phoneNumText);
                    if (phoneSaved) {
                        mNotificationManager.saveNotificationsPrefs(true);
                        Toast.makeText(view.getContext(), "Notifications enabled", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(view.getContext(), "Error saving phone", Toast.LENGTH_SHORT).show();
                        Toast.makeText(view.getContext(), "Enter phone number first", Toast.LENGTH_SHORT).show();
                        mNotificationsSwitch.setChecked(false);
                        mNotificationsSwitch.setThumbDrawable(getDrawable(getContext(), R.drawable.ic_cancel));
                    }
                }
            });
            builder.setNegativeButton("Cancel", (dialogInterface, j) -> {
                mNotificationManager.saveNotificationsPrefs(false);
                Toast.makeText(view.getContext(), "Notifications disabled", Toast.LENGTH_SHORT).show();
                mNotificationsSwitch.setChecked(false);
                mNotificationsSwitch.setThumbDrawable(getDrawable(getContext(), R.drawable.ic_cancel));
            });

            builder.create();
            builder.show();
        }
    }
}