package com.cs360.cknupp_weighttracker;

//to pass user between login and confirm screen
import android.os.Parcel;
import android.os.Parcelable;

public class NewUser implements Parcelable {
    private String mUsername;
    private String mPassword;

    public NewUser(String username,String password) {
        this.mUsername = username;
        this.mPassword = password;
    }

    protected NewUser(Parcel in) {
        mUsername = in.readString();
        mPassword = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mUsername);
        dest.writeString(mPassword);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<NewUser> CREATOR = new Creator<NewUser>() {
        @Override
        public NewUser createFromParcel(Parcel in) {
            return new NewUser(in);
        }

        @Override
        public NewUser[] newArray(int size) {
            return new NewUser[size];
        }
    };

    public void setUsername (String username) {
        mUsername = username;
    }

    public void setPassword (String password) {
        mPassword = password;
    }

    public String getUsername () {
        return mUsername;
    }

    public String getPassword () {
        return mPassword;
    }
}
