package com.cs360.cknupp_weighttracker;


// for user management
public class AuthenticatedUser {
    private String userName;
    private long userID;

    public AuthenticatedUser(long userId, String username){
        this.userName = username;
        this.userID = userId;
    }

    public String getUserName() {
        return userName;
    }
    public long getUserID() {
        return userID;
    }

}
